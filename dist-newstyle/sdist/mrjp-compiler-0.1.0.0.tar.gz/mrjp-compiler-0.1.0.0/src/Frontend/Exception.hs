module Frontend.Exception where

import Latte.Abs

errMessage :: BNFC'Position -> String -> String
errMessage line message =
  case line of
    Just (line, col) -> "ERROR: line " ++ show line ++ " column " ++ show col ++ ": " ++ message
    Nothing -> "ERROR: " ++ message

-- data StaticTypingException
--     = AssignmentMismatch
--     | Redeclared Ident
--     | TypeMismatch Type Type
--     | Undefined Ident
--     | InvalidIndirect Type
--     | InvalidOperation
--     | ReturnTooMany
--     | ReturnNotEnough
--     | MissingReturn
--     | NonBoolCondition Type
--     | FuncNotCalled
--     | NonRetFuncAsValue
--     | CallNonFunction Ident Type
--     | UntypedNil
--     | MainUndeclared
--     | MainWrongType

