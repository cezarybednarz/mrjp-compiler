module Frontend.Typecheck where

import Latte.Abs
import Data.Map as Map 
import Frontend.Environment
import Frontend.Exception
import Control.Monad.State
import Control.Monad.Reader
import Control.Monad.Except
import Data.Maybe

-- Memory Management -- 

alloc :: TM Loc
alloc = do
  gets Map.size

insertValue :: Loc -> Val -> TM ()
insertValue loc val = do
  store' <- gets (Map.insert loc val)
  put store'

declareVar :: Ident -> Val -> TM ValEnv
declareVar id val = do
  loc <- alloc
  valEnv' <- asks (Map.insert id loc . fst)
  insertValue loc val
  return valEnv'

declareFunc :: Ident -> Func -> TM FuncEnv
declareFunc id func = do
  asks (Map.insert id func . snd)

-- TopDef --

addTopDef :: TopDef -> TM Env
addTopDef (FnDef line t id args b) = do
  (valEnv, _) <- ask
  funcEnv <- declareFunc id (VFunc t id args b)
  return (valEnv, funcEnv)

addTopDefs :: [TopDef] -> TM Env
addTopDefs [] = ask
addTopDefs (def:ds) = do
  newEnv <- addTopDef def
  local (const newEnv) $ addTopDefs ds

-- evalExpr --

evalExpr :: Expr -> TM Val
evalExpr (EApp line id exprs) = do
  throwError $ errMessage line $ "TODO function " ++ show id ++ " has wrong type"
