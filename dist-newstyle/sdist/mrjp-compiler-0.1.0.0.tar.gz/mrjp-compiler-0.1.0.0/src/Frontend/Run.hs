module Frontend.Run where

import Latte.Abs
import Frontend.Environment
import Frontend.Typecheck
import Control.Monad.State
import Control.Monad.Reader
import Control.Monad.Except

-- run Typechecker Monad --

runTM :: TM a -> Store -> Env -> IO (Either String a, Store)
runTM m st en = runStateT (runExceptT (runReaderT m en)) st

-- Start program from main --

typecheckProgram :: Program -> IO (Either String Val, Store)
typecheckProgram program =
  runTM (runMain program) initStore initEnv

runMain :: Program -> TM Val
runMain (Program line tds) = do
  env <- addTopDefs tds
  local (const env) $ evalExpr $ EApp line (Ident "main") []


