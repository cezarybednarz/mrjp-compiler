module Grammar.Test (printTest) where

printTest :: String 
printTest = "costam "