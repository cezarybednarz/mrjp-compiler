# Kompilator języka Latte

generowanie nowej gramatyki : 
`bnfc --haskell --functor -d -o src Latte.cf`


